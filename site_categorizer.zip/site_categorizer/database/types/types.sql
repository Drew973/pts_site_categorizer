drop type if exists cat cascade;
--CREATE TYPE cat AS ENUM ('A','B','C','Q1','G1','S1','Q2','R','S2','Q3','G2','K');

CREATE TYPE cat AS ENUM ('A','B','C','Q1','G1','S1','Q2','Q3','R','G2','S2','K');


