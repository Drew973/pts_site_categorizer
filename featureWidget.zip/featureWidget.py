from PyQt5.QtWidgets import QLineEdit,QCompleter,QApplication
from PyQt5.QtCore import QStringListModel

from PyQt5.QtGui import QValidator

import sys


class whiteListValidator(QValidator):

    def __init__(self,parent=None,model=None,column=0):
        super(QValidator,self).__init__(parent)
        self.setModel(model)
        self.setColumn(column)


    def validate(self,input,pos):
       # return  QValidator.Acceptable
      #  return (QValidator.Acceptable, input, pos)
        
        
        #print('input:%s' % (str(input)))
        self.default =(QValidator.Acceptable, input, pos)
 
        if self.model is None:
            return self.default
            
        if self.column is None:
            return self.default
        
        for i in range(self.model.rowCount()):
            
            #print(str(self.model.index(i, self.column).data()))
            
            if str(self.model.index(i, self.column).data())==input:
                #print('valid')
                return (QValidator.Acceptable,input,pos)
                
                
        return (QValidator.Intermediate,input,pos)
        
        
    def setColumn(self,column):
        self.column = column

    def setModel(self,model):
        self.model = model
    
'''
widget to select a value from column of model.
can attempy to set value from seleted features of layer.
use distinct values. error message if >1 distinct value selected.
focus tries to select features on layer where field==value.
'''


class featureWidget(QLineEdit):

    def __init__(self,parent=None,model=None,column=None,layer=None,field=None):
        super().__init__(parent)
        
        self.setCompleter(QCompleter(self))
        self.setValidator(whiteListValidator(parent=self))
        
        self.completer().setModelSorting(QCompleter.CaseInsensitivelySortedModel)
        self.setModel(model)
        
        if column:
            self.setColumn(column)
            
        self.setLayer(layer)
        self.field = field


    def setLayer(self,layer):
        self.layer = layer
        
 
    def setModel(self,model):
        if self.completer():
            self.completer().setModel(model)
            self.validator().setModel(model)
    
    #column=int or str
    def setColumn(self,column=-1):
        if isinstance(column,str):
            column = self.model.fieldIndex(str)
            
        if isinstance(column,int):
            self.completer().setCompletionColumn(column)
            self.validator().setColumn(column)
 
    
    def feature(self):
        return self.text()



if __name__=='__console__':
    #layer = iface.activeLayer()
    w = featureWidget()
    m = QStringListModel(['aa','ab','ac'])
    w.setModel(m)
   # w.setColumn(0)
    w.show()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    
    w = featureWidget()
    m = QStringListModel(['aa','ab','ac'])
    w.setModel(m)
    w.show()
    
    sys.exit(app.exec_())  
   
    